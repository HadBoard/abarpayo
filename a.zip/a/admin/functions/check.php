<?
include("database.php");

$action = new Action();

echo $action->url();